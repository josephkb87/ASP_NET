# Secure-ASP_NET-MVC-5-web-App_LogIn_Email_Confirmation_Password_Reset-C-
This was a trial and error for setting up the secure ASP_NET_MVC_5_Web_App_Login_Email_Password_Reset
